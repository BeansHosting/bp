import { EntityHealthComponent, system, world } from "@minecraft/server";
import { configDB } from "../commands/config";
import { formatDateNow, getScore, metricNumbers, metricNumber, TitleAnimation, placeHolders, getPlayerCPS, combatCooldownMap } from "../Recursos/functions";
import { xpNeeded } from "../Recursos/pluginsRes";
import BPlayer from "../Recursos/BetterPlayer";
import { onlineDB, tps } from "../Recursos/plrStart";
import { animationFrames } from "../../config";
import { factionsDb } from "../../Core/mainCore";
const config = configDB.get('main')
let tituloColorIndexMap = new WeakMap();
let frameIndexMap = new WeakMap();

function animateFrames(player) {
    if (!frameIndexMap.has(player)) { frameIndexMap.set(player, 0) }
    const currentFrame = animationFrames[frameIndexMap.get(player)];
    frameIndexMap.set(player, (frameIndexMap.get(player) + 1) % animationFrames.length);
    return currentFrame;
}

const scoreKeys = ["Kills", "Deaths", "levelm", "XP", "banco", "racha"];
system.runInterval(() => {
    if (!config.Utility.Server.scoreboard) return
    world.getPlayers({ excludeTags: ['noSB'] }).forEach(player => {
        if (!player.isValid()) return
        if (!tituloColorIndexMap.has(player)) {
            tituloColorIndexMap.set(player, 0);
        }
        const animation = new TitleAnimation({
            title: config.scoreboard.title,
            colors: config.scoreboard.titleColors,
            animation: config.scoreboard.animation
        }, tituloColorIndexMap);
        const fac = `fac${getScore(player, 'fac_id')}`
        const value = factionsDb.get(fac)
        let role;
        if (value) {
            const playerInfo = value.membersList.find(member => member.id == player.id)
            role = playerInfo.role
        }
        const scores = getScores(player, scoreKeys);
        const { Kills, Deaths, levelm: currentLevel, XP: currentXP, banco, racha } = scores;
        const kdrFormatted = (Deaths !== 0) ? (Kills / Deaths).toFixed(2) : Kills;
        const health = Math.round(player.getComponent(EntityHealthComponent.componentId).currentValue);
        const replacements = {
            '$cps': getPlayerCPS(player),
            '$bars': animateFrames(player),
            '$rank': getRank(player, config.defaultRank),
            '$job': player.getTags().filter(tag => tag.startsWith('job:')).map(tag => tag.replace('job:', '')),
            '$date': formatDateNow(Date.now(), config.timeZone, false),
            '$name': BPlayer.getNameNC(player),
            '$online': world.getAllPlayers().length,
            '$clog': getCombatCooldown(player),
            '$money': metricNumbers(getScore(player, config.currency)),
            '$bank': metricNumbers(banco),
            '$kills': Kills,
            '$faction': BPlayer.getFaction(player) ?? 'N/A',
            '$kdr': kdrFormatted,
            '$deaths': Deaths,
            '$level': currentLevel,
            '$xp': (currentLevel === 500) ? 'Max' : currentXP,
            '$maxxp': getMaxXP(currentLevel),
            '$hp': health,
            '$killstreak': racha,
            '$tps': tps.toFixed(),
            '$members': metricNumber((Object.entries(onlineDB.collection())).length),
            '$title': animation.animate(player),
            '$facbadge': value && value.leader ? (value.leader.id === player.id ? '' : '') : '',
            '$facname': value?.factionName ?? 'N/A',
            '$facrole': role ?? 'N/A',
            '$facbank': metricNumbers(value?.bank) ?? 'N/A',
            '$facpower': metricNumbers(value?.power) ?? 'N/A'
        };
        player.onScreenDisplay.setTitle(placeHolders(config.scoreboard.sidebar, replacements, player));
    });
}, 6);

function getScores(player, scoreKeys) {
    return scoreKeys.reduce((obj, key) => {
        obj[key] = getScore(player, key);
        return obj;
    }, {});
}

function getMaxXP(currentLevel) {
    if (currentLevel === 500) {
        return 'Max';
    } else {
        const xpNeededForLevel = xpNeeded[Math.min(currentLevel - 1, xpNeeded.length - 1)];
        return xpNeededForLevel;
    }
}

function getRank(player, defaultRank) {
    const ranks = player.getTags().filter(tag => tag.startsWith('rank:')).map(tag => tag.replace('rank:', ''));
    return ranks.length > 0 ? ranks[0] : defaultRank;
}

function getCombatCooldown(player) {
    const combatCooldown = combatCooldownMap.get(player);
    if (combatCooldown) {
        const elapsedMilliseconds = Date.now() - combatCooldown.startTime;
        const remainingMilliseconds = combatCooldown.duration * 50 - elapsedMilliseconds; // Convert ticks to milliseconds
        const remainingSeconds = Math.ceil(remainingMilliseconds / 1000);
        return `${remainingSeconds}`;
    }
    return '0';
}

/*
for (const member of memberList)
        members.push(`§eMember name: §a${member[0].slice(1)}§e, join date: §a${MS(Date.now() - Number(dateReg.find(member[1]) ?? 0))} ago§e, member ID:§a ${member[1]}`);
    plr.send(`§aCongratulations§e! This server has §c${metricNumbers(len)}§e members! Here is a list of them:\n${members.join('\n')}\n§ePage §a${page}§e/§a${memberList.length}§e. §cPlease remember that the dates are not 100%% accurate.`);
*/
